package com.niit.homecontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
ModelAndView home;
@RequestMapping("/")
public ModelAndView discountData(){
	home=new ModelAndView("home_page");
	return home;
}

}
